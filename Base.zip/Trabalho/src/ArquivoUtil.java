import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ArquivoUtil {

    // Abre um arquivo dentro de /resources usando getResourceAsStream
    public static BufferedReader abrirRecurso(String caminho) {
        InputStream input = ArquivoUtil.class.getResourceAsStream(caminho);

        return new BufferedReader(new InputStreamReader(input));
    }

    // Lê um arquivo e retorna todas as linhas como ArrayList
    public static List<String> lerArquivoComoLista(String caminho) {
        List<String> linhas = new ArrayList<>();

        try (BufferedReader br = abrirRecurso(caminho)) {
            String linha;
            while ((linha = br.readLine()) != null) {
                linhas.add(linha);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return linhas;
    }

    // Lê arquivo e retorna como vetor de String
    public static String[] lerArquivoComoVetor(String caminho) {
        List<String> lista = lerArquivoComoLista(caminho);
        return lista.toArray(new String[0]);
    }
}