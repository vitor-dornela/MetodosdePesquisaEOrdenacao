public class NomeReader {

    public static String[] ler() {
        return ArquivoUtil.lerArquivoComoVetor("/nome.txt");
    }

    public static void main(String[] args) {
        String[] dados = ler();

        for (String linha : dados) {
            System.out.println(linha);
        }
    }
}